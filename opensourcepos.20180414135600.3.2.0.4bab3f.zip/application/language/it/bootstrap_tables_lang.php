<?php 

$lang["tables_all"] = "Tutti/e";
$lang["tables_columns"] = "Colonne";
$lang["tables_hide_show_pagination"] = "Nascondi/mostra paginazione";
$lang["tables_loading"] = "Caricamento, attendere prego...";
$lang["tables_page_from_to"] = "Mostro {0} a {1} di {2} righe";
$lang["tables_refresh"] = "Ricarica";
$lang["tables_rows_per_page"] = "{0} righe per pagina";
$lang["tables_toggle"] = "Inverti";
