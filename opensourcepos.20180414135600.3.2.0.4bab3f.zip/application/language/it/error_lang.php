<?php 

$lang["error_no_permission_module"] = "Non disponi dei permessi per accedere al seguente modulo";
$lang["error_unknown"] = "Errore sconosciuto";
