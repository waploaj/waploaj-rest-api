<?php 

$lang["datepicker_all_time"] = "Alle";
$lang["datepicker_apply"] = "Toepassen";
$lang["datepicker_cancel"] = "Annuleren";
$lang["datepicker_custom"] = "Aangepaste";
$lang["datepicker_from"] = "Van";
$lang["datepicker_last_30"] = "Vorige 30 Dagen";
$lang["datepicker_last_7"] = "Vorige 7 Dagen";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Vorige Maand";
$lang["datepicker_last_year"] = "Vorig Jaar";
$lang["datepicker_same_month_last_year"] = "Dezelfde maand vorig jaar";
$lang["datepicker_same_month_to_same_day_last_year"] = "Dezelfde maand op dezelfde dag vorig jaar";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Deze Maand";
$lang["datepicker_this_year"] = "Dit Jaar";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "Vandaag";
$lang["datepicker_today_last_year"] = "Vandaag vorig jaar";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Gisteren";
