<?php 

$lang["enum_half_down"] = "Half Omlaag";
$lang["enum_half_even"] = "Half Even";
$lang["enum_half_five"] = "Half Vijf";
$lang["enum_half_odd"] = "Half Oneven";
$lang["enum_half_up"] = "Half Boven";
$lang["enum_round_down"] = "Naar Beneden";
$lang["enum_round_up"] = "Naar Boven";
