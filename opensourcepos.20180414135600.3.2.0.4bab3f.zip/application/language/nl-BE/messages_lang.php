<?php 

$lang["messages_first_name"] = "Voornaam";
$lang["messages_last_name"] = "Achternaam";
$lang["messages_message"] = "Message";
$lang["messages_message_placeholder"] = "Jou bericht hier..";
$lang["messages_message_required"] = "Bericht verplicht";
$lang["messages_multiple_phones"] = "(In het geval van meerdere ontvangers, voer de mobiele nummers gescheiden door komma's in)";
$lang["messages_phone"] = "Telefoonnummer";
$lang["messages_phone_number_required"] = "Telefoonnummer verplicht";
$lang["messages_phone_placeholder"] = "Mobiele nummer(s) hier...";
$lang["messages_sms_send"] = "Send SMS";
$lang["messages_successfully_sent"] = "Bericht met succes verzonden naar: ";
$lang["messages_unsuccessfully_sent"] = "Bericht zonder succes verzonden naar: ";
