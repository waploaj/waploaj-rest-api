<?php 

$lang["tables_all"] = "All";
$lang["tables_columns"] = "Columns";
$lang["tables_hide_show_pagination"] = "Hide/Show pagination";
$lang["tables_loading"] = "Loading, please wait...";
$lang["tables_page_from_to"] = "Showing {0} to {1} of {2} rows";
$lang["tables_refresh"] = "Refresh";
$lang["tables_rows_per_page"] = "{0} rows per page";
$lang["tables_toggle"] = "Toggle";
