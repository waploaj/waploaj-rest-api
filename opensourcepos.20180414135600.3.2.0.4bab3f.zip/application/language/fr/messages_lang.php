<?php 

$lang["messages_first_name"] = "Prénon";
$lang["messages_last_name"] = "Nom de famille";
$lang["messages_message"] = "Message";
$lang["messages_message_placeholder"] = "Votre message ici...";
$lang["messages_message_required"] = "Message requis";
$lang["messages_multiple_phones"] = "(Si plusieur destinataires, séparer les numéros avec une virgule)";
$lang["messages_phone"] = "N° de téléphone";
$lang["messages_phone_number_required"] = "N° de téléphone requis";
$lang["messages_phone_placeholder"] = "N° de téléphone portable ici...";
$lang["messages_sms_send"] = "Envoier SMS";
$lang["messages_successfully_sent"] = "Message envoyé avec succès à : ";
$lang["messages_unsuccessfully_sent"] = "Message non envoyer du a une erreur: ";
