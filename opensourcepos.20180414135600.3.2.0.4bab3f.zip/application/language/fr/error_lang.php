<?php 

$lang["error_no_permission_module"] = "Vous n'avez pas d'autorisation d'accès pour le module";
$lang["error_unknown"] = "inconnu";
