<?php 

$lang["tables_all"] = "ທັງໝົດ";
$lang["tables_columns"] = "ຖັນ";
$lang["tables_hide_show_pagination"] = "ເຊື່ອງ/ສະແດງເລກທີໜ້າເຈ້ຍ";
$lang["tables_loading"] = "ກຳລັງໂຫຼດ, ກະລຸນາລໍຖ້າ...";
$lang["tables_page_from_to"] = "ສະແດງ {0} ຫາ {1} ຂອງ {2} ແຖວ";
$lang["tables_refresh"] = "Refresh";
$lang["tables_rows_per_page"] = "{0} ແຖວຕໍ່ໜ້າ";
$lang["tables_toggle"] = "Toggle";
